const String SplashScreenRoute = '/';
const String EmojiScreenRoute = '/Emoji';
const String EmojiConverterScreenRoute = '/EmojiConverter';
const String BLEScreenRoute = '/BLEList';
