import 'package:flutter/material.dart';

// Colors
const kMainBG = Color(0xff191720);
const kTextFieldFill = Color(0xff1E1C24);
const kCardBG = Color(0xffffffff);
