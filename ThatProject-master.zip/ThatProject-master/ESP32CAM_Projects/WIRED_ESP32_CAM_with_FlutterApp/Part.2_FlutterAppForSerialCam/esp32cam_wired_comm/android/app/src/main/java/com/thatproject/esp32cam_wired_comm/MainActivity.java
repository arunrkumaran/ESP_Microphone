package com.thatproject.esp32cam_wired_comm;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
