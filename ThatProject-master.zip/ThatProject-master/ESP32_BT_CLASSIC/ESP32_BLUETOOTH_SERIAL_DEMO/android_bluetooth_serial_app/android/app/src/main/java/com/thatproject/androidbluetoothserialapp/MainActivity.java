package com.thatproject.androidbluetoothserialapp;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
